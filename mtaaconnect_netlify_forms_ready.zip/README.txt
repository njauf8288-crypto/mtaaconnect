MTAACONNECT — WEBSITE STARTER PACKAGE
======================================

WHAT'S INCLUDED
- index.html: responsive homepage
- styles.css: responsive mobile/desktop styling
- app.js: browser search, category filters and demo interactions
- logo.svg: brand mark
- privacy.html and terms.html: starter policy pages to customise
- robots.txt and sitemap.xml: update the domain before publishing
- NEXT_STEP_LAUNCH_KIT.txt: phone-first zero-budget seller onboarding and launch plan

IMPORTANT TRUTH
This is a front-end starter, not a fully connected marketplace. Demo listings are examples and must be replaced with genuine listings with seller permission. The existing business form stores drafts in the visitor's browser only; it does not send applications to you. There is no database, user accounts, admin dashboard, real-time inventory, payment processing or automated seller verification. No website guarantees profit.

YOUR NEXT CONCRETE STEP
Open NEXT_STEP_LAUNCH_KIT.txt and follow “DO THIS FIRST”. Create a Google Form connected to a private Google Sheet, then replace the website's “Add my business” button with the form URL. This gives you a workable manual seller-intake flow without paying for a custom backend. Keep seller applications private and approve listings manually.

FREE HOSTING
You can publish the static folder using a host with a free tier, such as GitHub Pages, Netlify, or Cloudflare Pages. Check current terms and limits before choosing. Test the published site on your phone and update sitemap.xml/robots.txt with the real domain.

BEFORE LAUNCH
- Replace demo cards with real, permission-based listings.
- Set up a dedicated contact email and protect it with 2-step verification.
- Add the seller form, verified WhatsApp contact links, and a report-listing contact.
- Customise privacy and terms for what you actually collect and do.
- Make clear that MtaaConnect is a directory and does not guarantee products, sellers or sales.

REVENUE PATH
Start with free listings. When you can demonstrate real traffic and seller enquiries, test labelled featured listings or sponsorships. Do not charge for guaranteed sales or traffic you cannot prove. Use a suitable payment provider if you later charge online; do not store card details yourself.

Review Kenyan privacy, consumer, tax and business obligations before scaling. Photos and descriptions must be used with permission.


NETLIFY BUSINESS LISTING FORM UPDATE
1. In Netlify, open your MtaaConnect project and choose Deploys.
2. On your phone, extract this ZIP into a folder if needed.
3. Open Netlify Drop or the manual deploy area and upload the CONTENTS of this folder (the index.html file must be at the top level).
4. Wait until the new deploy says Published.
5. Open Forms in the Netlify project. Look for the form named business-listing.
6. Test by submitting a sample listing on the live site, then check Forms > Submissions.
Email notifications are configured separately in Netlify Forms settings. Submissions are sent to Netlify for review and are not automatically published as public listings.
