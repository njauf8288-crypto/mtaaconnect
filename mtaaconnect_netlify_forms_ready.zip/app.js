const listings=[
{name:"Savanna Kitchen",category:"Food",area:"Nairobi",desc:"A welcoming neighbourhood food spot for tasty meals and good company.",rating:"Demo",price:"Ask for menu",image:"https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=900&q=80",tag:"Food & drink"},
{name:"Urban Sole Boutique",category:"Fashion",area:"Nairobi",desc:"Everyday style, fresh looks and footwear for every occasion.",rating:"Demo",price:"Ask for prices",image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80",tag:"Fashion"},
{name:"Glow Studio",category:"Beauty",area:"Nairobi",desc:"A friendly beauty space for a fresh look and a little self-care.",rating:"Demo",price:"Ask to book",image:"https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=900&q=80",tag:"Beauty & care"},
{name:"FixRight Services",category:"Services",area:"Kiambu",desc:"Practical home and small-business maintenance services.",rating:"Demo",price:"Request a quote",image:"https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=900&q=80",tag:"Services"},
{name:"The Gift Corner",category:"Shopping",area:"Nairobi",desc:"Thoughtful gifts and small surprises for special moments.",rating:"Demo",price:"Ask for prices",image:"https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&w=900&q=80",tag:"Shopping"},
{name:"Daily Brew Café",category:"Food",area:"Nakuru",desc:"Coffee, light bites and a comfortable place to catch up.",rating:"Demo",price:"Ask for menu",image:"https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=900&q=80",tag:"Food & drink"}
];
let activeCategory="All";
const $=id=>document.getElementById(id);
function safe(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderListings(){
 const q=$("q").value.trim().toLowerCase(), area=$("area").value.trim().toLowerCase();
 const filtered=listings.filter(x=>(activeCategory==="All"||x.category===activeCategory)&&(!q||(x.name+" "+x.category+" "+x.desc+" "+x.area).toLowerCase().includes(q))&&(!area||x.area.toLowerCase().includes(area)));
 $("listingGrid").innerHTML=filtered.map(x=>`<article class="listing"><div class="listing-photo" style="background-image:url('${x.image}')"><span class="listing-tag">${safe(x.tag)}</span><button class="save" aria-label="Save ${safe(x.name)}" data-save="${safe(x.name)}">♡</button></div><div class="listing-body"><div class="listing-meta"><span>⌖ ${safe(x.area)}</span><span class="rating">✦ ${safe(x.rating)}</span></div><h3>${safe(x.name)}</h3><p>${safe(x.desc)}</p><div class="listing-foot"><span class="sample">DEMO EXAMPLE</span><button data-details="${safe(x.name)}">About this listing ↗</button></div></div></article>`).join("");
 $("emptyState").hidden=filtered.length!==0;
}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400);}
$("menuBtn").addEventListener("click",()=>$("nav").classList.toggle("open"));
$("nav").querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>$("nav").classList.remove("open")));
$("categoryGrid").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;activeCategory=b.dataset.category;document.querySelectorAll(".category").forEach(c=>c.classList.toggle("active",c===b));renderListings();$("listings").scrollIntoView({behavior:"smooth"});});
$("searchForm").addEventListener("submit",e=>{e.preventDefault();activeCategory="All";document.querySelectorAll(".category").forEach(c=>c.classList.toggle("active",c.dataset.category==="All"));renderListings();$("listings").scrollIntoView({behavior:"smooth"});});
["q","area"].forEach(id=>$(id).addEventListener("input",renderListings));
$("listingGrid").addEventListener("click",e=>{
 const save=e.target.closest("[data-save]");if(save){const name=save.dataset.save;let saved=[];try{saved=JSON.parse(localStorage.getItem("mtc_saved")||"[]")}catch{};if(saved.includes(name)){saved=saved.filter(x=>x!==name);save.textContent="♡";toast("Removed from saved examples");}else{saved.push(name);save.textContent="♥";toast("Saved on this device");}localStorage.setItem("mtc_saved",JSON.stringify(saved));return;}
 const detail=e.target.closest("[data-details]");if(detail)toast("Demo example only. Replace it with a real verified business listing.");
});
function syncSaved(){let saved=[];try{saved=JSON.parse(localStorage.getItem("mtc_saved")||"[]")}catch{};$("listingGrid").querySelectorAll("[data-save]").forEach(b=>{if(saved.includes(b.dataset.save))b.textContent="♥"});}
function openModal(){$("businessModal").classList.add("show");$("businessModal").setAttribute("aria-hidden","false");}
function closeModal(){$("businessModal").classList.remove("show");$("businessModal").setAttribute("aria-hidden","true");}
$("openModal").addEventListener("click",openModal);$("closeModal").addEventListener("click",closeModal);
$("businessModal").addEventListener("click",e=>{if(e.target.id==="businessModal")closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
$("businessForm").addEventListener("submit",async e=>{
 e.preventDefault();
 const form=e.target;
 const submitButton=form.querySelector('button[type="submit"],button:not([type])');
 const result=$("formResult");
 const originalLabel=submitButton?submitButton.textContent:"Submit business for review";
 if(submitButton){submitButton.disabled=true;submitButton.textContent="Sending…";}
 result.textContent="Sending your business details securely to the website form service…";
 try{
   const formData=new FormData(form);
   formData.set("form-name","business-listing");
   const response=await fetch("/",{
     method:"POST",
     headers:{"Content-Type":"application/x-www-form-urlencoded"},
     body:new URLSearchParams(formData).toString()
   });
   if(!response.ok) throw new Error("Submission failed");
   result.textContent="Thank you! Your business details have been submitted for review. They are not published automatically.";
   form.reset();
 }catch(error){
   result.textContent="We couldn't send this form just now. Please try again when the site has been redeployed with Netlify Forms enabled.";
 }finally{
   if(submitButton){submitButton.disabled=false;submitButton.textContent=originalLabel;}
 }
});
$("year").textContent=new Date().getFullYear();renderListings();syncSaved();